export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyBA_9cKTG9i_lB9neftIp0Ns_5YfUvk_nc",
    authDomain: "mealsapp-6d3f4.firebaseapp.com",
    projectId: "mealsapp-6d3f4",
    storageBucket: "mealsapp-6d3f4.firebasestorage.app",
    messagingSenderId: "599130327839",
    appId: "1:599130327839:web:ee336b8e0c0311e6f17e2a",
    measurementId: "G-GCTVZHXRC2"
  }
};
